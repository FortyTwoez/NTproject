package ru.appline.logic;

public class RangeDegrees {

    private String range;

    public RangeDegrees() {

        super();
    }

    public String getRange() {
        return range;
    }

    public void setRange(String range) {
        this.range = range;
    }

    public RangeDegrees(String range) {
        this.range = range;
    }

    public int get1(){

        String[] range = this.range.split("-");

        return Integer.parseInt(range[0]);
    }

    public int get2(){

        String[] range = this.range.split("-");

        return Integer.parseInt(range[1]);
    }
}