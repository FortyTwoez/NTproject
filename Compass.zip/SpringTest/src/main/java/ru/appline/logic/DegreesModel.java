package ru.appline.logic;


import java.util.HashMap;
import java.util.Map;

public class DegreesModel {

    private static DegreesModel instance = new DegreesModel();

    private final Map<String, RangeDegrees> model;

    public DegreesModel() {

        model = new HashMap<String, RangeDegrees>();

    }

    public static DegreesModel getInstance() {

        return instance;
    }

    public void add(Map<String, RangeDegrees> model) {

        this.model.putAll(model);

    }

    public String returnSide(int degree){

        for(Map.Entry<String, RangeDegrees> s : model.entrySet()){
            int degrees1 = s.getValue().get1();
            int degrees2 = s.getValue().get2();

            if(degrees1 <= degree & degree <= degrees2){
                return s.getKey();
            } else if((degrees1 - degrees2 > 0) &
                    (degree <= degrees2 | degree >= degrees1)){
                return s.getKey();
            }
        }
        return "Неверно введен градус!";
    }

}

