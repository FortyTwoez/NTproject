package ru.appline.controller;



import org.springframework.web.bind.annotation.*;
import ru.appline.logic.DegreesModel;
import ru.appline.logic.RangeDegrees;

import java.util.HashMap;
import java.util.Map;


@RestController

public class Controller {

    private static final DegreesModel degreesModel = DegreesModel.getInstance();


    @PostMapping(value = "/postDegrees", consumes = "application/json")

    public void postDegrees(@RequestBody Map<String, RangeDegrees> model) {

        degreesModel.add(model);

    }

    @GetMapping(value = "/getDegrees", consumes = "application/json", produces = "application/json")

    public Map<String, String> getDegrees(@RequestBody Map<String, Integer> degrees) {

        Map<String, String> answer = new HashMap<String, String>();

        String side = degreesModel.returnSide(degrees.get("Degrees"));

        answer.put("Side", side);

        return answer;
    }


    }

